
const campaigns = [
  {campaign:"Fall Tour Presale",channel:"Email",segment:"High-intent fans",delivered:48200,open_rate:47.8,click_rate:8.9,conversion_rate:4.6,tickets:2217,qa:"Passed"},
  {campaign:"Venue Weekend Reminder",channel:"SMS",segment:"Local attendees",delivered:18750,open_rate:96.0,click_rate:14.8,conversion_rate:6.2,tickets:1163,qa:"Passed"},
  {campaign:"Comedy Club Onsale",channel:"Email",segment:"Comedy affinity",delivered:26400,open_rate:42.1,click_rate:7.2,conversion_rate:3.8,tickets:1003,qa:"Passed"},
  {campaign:"Last Chance Tonight",channel:"SMS",segment:"Clicked, not purchased",delivered:7100,open_rate:97.0,click_rate:18.6,conversion_rate:9.1,tickets:646,qa:"Passed"},
  {campaign:"Indie Night Presale",channel:"Email",segment:"Indie music fans",delivered:33100,open_rate:38.7,click_rate:5.1,conversion_rate:2.4,tickets:794,qa:"Review"},
  {campaign:"VIP Upgrade Nudge",channel:"Email",segment:"Ticket holders",delivered:11900,open_rate:51.3,click_rate:9.8,conversion_rate:5.5,tickets:655,qa:"Passed"},
  {campaign:"Friday Venue Drop",channel:"SMS",segment:"Recent venue visitors",delivered:15400,open_rate:95.0,click_rate:12.2,conversion_rate:4.7,tickets:724,qa:"Passed"},
  {campaign:"Fall Concert Roundup",channel:"Email",segment:"Broad local audience",delivered:55200,open_rate:35.4,click_rate:4.4,conversion_rate:1.9,tickets:1049,qa:"Review"}
];

const cf=document.getElementById("channelFilter"), sf=document.getElementById("segmentFilter");
[...new Set(campaigns.map(x=>x.segment))].forEach(s=>sf.insertAdjacentHTML("beforeend",`<option>${s}</option>`));

function avg(a,k){ return a.length ? a.reduce((s,x)=>s+x[k],0)/a.length : 0; }
function fmt(n){ return new Intl.NumberFormat().format(n); }

function filtered(){
  return campaigns.filter(x => (cf.value==="All"||x.channel===cf.value) && (sf.value==="All"||x.segment===sf.value));
}

function render(){
  const data=filtered();
  const delivered=data.reduce((s,x)=>s+x.delivered,0);
  const tickets=data.reduce((s,x)=>s+x.tickets,0);
  const qaRate=data.length ? (data.filter(x=>x.qa==="Passed").length/data.length*100) : 0;
  document.getElementById("kpis").innerHTML = `
    <div class="kpi"><div class="label">Messages delivered</div><div class="value">${fmt(delivered)}</div><div class="note">Email + SMS volume</div></div>
    <div class="kpi"><div class="label">Avg. click rate</div><div class="value">${avg(data,"click_rate").toFixed(1)}%</div><div class="note">Directional engagement signal</div></div>
    <div class="kpi"><div class="label">Ticket conversions</div><div class="value">${fmt(tickets)}</div><div class="note">Synthetic attributed purchases</div></div>
    <div class="kpi"><div class="label">QA pass rate</div><div class="value">${qaRate.toFixed(0)}%</div><div class="note">${data.filter(x=>x.qa==="Review").length} campaign(s) flagged</div></div>`;
  const max=Math.max(...data.map(x=>x.conversion_rate),1);
  document.getElementById("barChart").innerHTML = data.map(x=>`
    <div class="bar-item"><div class="bar-label">${x.campaign}</div><div class="bar-track"><div class="bar-fill" style="width:${x.conversion_rate/max*100}%"></div></div><div class="bar-value">${x.conversion_rate.toFixed(1)}%</div></div>`).join("");
  document.getElementById("campaignTable").innerHTML = data.map(x=>`
    <tr><td><strong>${x.campaign}</strong></td><td><span class="badge ${x.channel.toLowerCase()}">${x.channel}</span></td>
    <td>${x.segment}</td><td>${fmt(x.delivered)}</td><td>${x.open_rate.toFixed(1)}%</td><td>${x.click_rate.toFixed(1)}%</td>
    <td>${x.conversion_rate.toFixed(1)}%</td><td>${fmt(x.tickets)}</td><td><span class="badge ${x.qa==="Passed"?"pass":"review"}">${x.qa}</span></td></tr>`).join("");
  document.getElementById("countBadge").textContent=`${data.length} campaigns`;
  const recs=[];
  const low=[...data].filter(x=>x.click_rate<5.5);
  if(low.length) recs.push(`<div class="rec"><strong>Review low-click campaigns</strong><span>${low.map(x=>x.campaign).join(", ")} fell below the 5.5% click threshold. Check subject line/message hierarchy, CTA clarity, and audience fit.</span></div>`);
  const high=[...data].sort((a,b)=>b.conversion_rate-a.conversion_rate)[0];
  if(high) recs.push(`<div class="rec"><strong>Scale the strongest journey</strong><span>${high.campaign} leads this view at ${high.conversion_rate.toFixed(1)}% conversion. Test a similar audience + urgency structure in the next campaign.</span></div>`);
  const review=data.filter(x=>x.qa==="Review");
  if(review.length) recs.push(`<div class="rec"><strong>Hold until QA clears</strong><span>${review.length} campaign(s) need segmentation review before reuse or relaunch.</span></div>`);
  if(!recs.length) recs.push(`<div class="rec"><strong>No active flags</strong><span>Current filtered campaigns are within the prototype thresholds.</span></div>`);
  document.getElementById("recommendations").innerHTML=recs.join("");
}
cf.addEventListener("change",render); sf.addEventListener("change",render); render();

const modal=document.getElementById("methodModal");
document.getElementById("methodBtn").onclick=()=>modal.showModal();
document.getElementById("closeModal").onclick=()=>modal.close();
