# Venue Lifecycle Marketing Lab

Independent portfolio project by Ashley Duke.

## Purpose
A static, browser-based marketing operations dashboard that demonstrates the workflow described in a venue lifecycle marketing coordinator role:
- build and schedule email/SMS campaigns
- execute templated communications and workflows
- validate links, audience segments, and scheduling
- support campaign QA and data validation
- monitor basic performance metrics
- flag optimization opportunities
- support reporting and documentation

## Data
All campaign data is synthetic and fictional. This project is not affiliated with Live Nation Entertainment, Ticketmaster, or any venue operator.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new GitHub repository, e.g. `venue-lifecycle-marketing-lab`.
2. Upload all files in this folder to the repository root.
3. In GitHub: Settings → Pages → Deploy from a branch → `main` / root.
4. Add the published URL to your resume/application portfolio section.
